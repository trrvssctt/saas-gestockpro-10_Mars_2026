
-- 1. Ajout de la colonne de liaison du plan dans tenants
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS plan VARCHAR(50);

-- 2. Ajout des colonnes de gestion de statut dans plans
ALTER TABLE plans ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'actif';
ALTER TABLE plans ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP WITH TIME ZONE;

-- 3. Mise à jour des index de performance
CREATE INDEX IF NOT EXISTS idx_tenant_plan_id ON tenants(plan);
CREATE INDEX IF NOT EXISTS idx_plans_status_active ON plans(status) WHERE status = 'actif';
