
import { User, UserRole } from '../types';

const AUTH_STORAGE_KEY = 'gsp_session_vault';

// LIMITES PLAN BASIC (CONFORME SPÉCIFICATIONS)
export const BASIC_LIMITS = {
  MAX_CUSTOMERS: 5,
  MAX_USERS: 3,
  MAX_MONTHLY_SALES: 20
};

export const authBridge = {
  saveSession: (user: User, token: string) => {
    const roles = Array.isArray(user.roles) ? user.roles : [user.role || UserRole.SALES];
    const sessionUser = { ...user, roles };
    sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify({ user: sessionUser, token, timestamp: Date.now() }));
  },

  getSession: (): { user: User; token: string } | null => {
    const raw = sessionStorage.getItem(AUTH_STORAGE_KEY);
    if (!raw) return null;
    try {
      const data = JSON.parse(raw);
      if (Date.now() - data.timestamp > 86400000) { 
        authBridge.clearSession(); 
        return null; 
      }
      return data;
    } catch { return null; }
  },

  fetchMe: async (token: string): Promise<User | null> => {
    try {
      const response = await fetch('http://localhost:3000/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const user = await response.json();
        return user;
      }
      return null;
    } catch { return null; }
  },

  clearSession: () => sessionStorage.removeItem(AUTH_STORAGE_KEY),

  canAccess: (user: User, moduleId: string): boolean => {
    const roles = Array.isArray(user.roles) ? user.roles : [user.role];
    const planId = user.planId;
    
    if (roles.includes(UserRole.SUPER_ADMIN)) return true;

    // Map sub-modules to parent modules for access check
    let effectiveModuleId = moduleId;
    if (moduleId.startsWith('hr_')) effectiveModuleId = 'rh';
    if (moduleId.startsWith('payroll_')) effectiveModuleId = 'payroll';
    
    // 🔒 RESTRICTION MODULES - PLAN BASIC (10 modules exactement)
    if (planId === 'BASIC') {
      const allowedForBasic = [
        'dashboard', 
        'categories', 
        'subcategories', 
        'inventory', 
        'services', 
        'customers', 
        'sales', 
        'payments', 
        'governance', 
        'subscription', 
        'settings'
      ];
      if (!allowedForBasic.includes(effectiveModuleId)) return false;
    }

    // 🔒 RESTRICTION MODULES - PLAN PRO
    if (planId === 'PRO') {
      const forbiddenForPro = ['rh', 'payroll'];
      if (forbiddenForPro.includes(effectiveModuleId)) return false;
    }

    if (roles.includes(UserRole.ADMIN)) {
      return effectiveModuleId !== 'superadmin';
    }

    const roleMap: Record<string, string[]> = {
      [UserRole.SALES]: ['dashboard', 'sales', 'customers', 'inventory', 'services'],
      [UserRole.STOCK_MANAGER]: ['dashboard', 'categories', 'subcategories', 'inventory', 'services'],
      [UserRole.ACCOUNTANT]: ['dashboard', 'sales', 'payments', 'customers', 'settings', 'services'],
      ['EMPLOYEE' as any]: ['dashboard', 'inventory', 'customers', 'services', 'rh']
    };

    return roles.some(r => (roleMap[r as any] || []).includes(effectiveModuleId));
  },

  canPerform: (user: User, action: 'CREATE' | 'EDIT' | 'DELETE' | 'VIEW', resource: string): boolean => {
    const roles = Array.isArray(user.roles) ? user.roles : [user.role];
    if (roles.includes(UserRole.SUPER_ADMIN) || roles.includes(UserRole.ADMIN)) return true;

    return roles.some(r => {
      if (r === UserRole.STOCK_MANAGER) return ['categories', 'subcategories', 'inventory', 'services'].includes(resource);
      if (r === UserRole.SALES) {
        if (['sales', 'customers', 'services'].includes(resource)) return true;
        return action === 'VIEW' && resource === 'inventory';
      }
      if (r === UserRole.ACCOUNTANT) {
        if (['payments', 'settings', 'services'].includes(resource)) return true;
        return action === 'VIEW';
      }
      return action === 'VIEW';
    });
  }
};
