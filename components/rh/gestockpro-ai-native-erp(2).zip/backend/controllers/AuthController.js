
import { AuthService } from '../services/AuthService.js';
import { sequelize } from '../config/database.js';
import { Op } from 'sequelize';
import bcrypt from 'bcrypt';
import crypto from 'crypto';

import User from '../models/User.js';
import Tenant from '../models/Tenant.js';
import Subscription from '../models/Subscription.js';
import Administrator from '../models/Administrator.js';
import AuditLog from '../models/AuditLog.js';

export class AuthController {
  static async login(req, res) {
    try {
      const email = (req.body.email || '').toLowerCase().trim();
      const password = (req.body.password || '').trim();
      
      const user = await AuthService.validateCredentials(email, password);

      if (!user) return res.status(401).json({ error: 'Identifiants invalides.' });
      
      // 1. Récupération de l'état de l'instance (Tenant) et du Plan
      const tenant = await Tenant.findByPk(user.tenantId);
      if (!tenant) return res.status(404).json({ error: 'Instance introuvable.' });

      // 2. Blocage Flux-Paiement : Vérification si le compte est actif et à jour
      const isTrial = tenant.paymentStatus === 'TRIAL';
      const isUpToDate = tenant.paymentStatus === 'UP_TO_DATE' || isTrial;
      
      if (!tenant.isActive || !isUpToDate) {
        return res.status(403).json({ 
          error: 'AccessBlocked', 
          message: 'Accès suspendu : Votre abonnement n’est pas à jour ou l’instance a été verrouillée. Veuillez régulariser votre situation dans l’onglet Paiement.' 
        });
      }

      // 3. Récupération du Plan ID depuis la table Subscription
      const sub = await Subscription.findOne({ where: { tenantId: user.tenantId } });
      const planId = sub ? sub.planId : 'FREE_TRIAL';

      // 4. Génération du token incluant le planId pour le frontend
      const token = AuthService.generateToken({
        ...user.toJSON(),
        planId: planId
      });

      const userRoles = Array.isArray(user.roles) ? user.roles : [user.role || 'EMPLOYEE'];
      
      return res.status(200).json({ 
        token, 
        user: { 
          id: user.id, 
          name: user.name, 
          role: userRoles[0], 
          roles: userRoles, 
          tenantId: user.tenantId,
          planId: planId
        } 
      });
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }

  static async verifyMFA(req, res) {
    try {
      const { userId, code } = req.body;
      const user = await User.findByPk(userId);
      if (!user) return res.status(404).json({ error: 'UserNotFound' });
      if (!code || code.length !== 6) {
        return res.status(401).json({ error: 'InvalidCode', message: 'Code de sécurité incorrect.' });
      }
      const sub = await Subscription.findOne({ where: { tenantId: user.tenantId } });
      const token = AuthService.generateToken({ ...user.toJSON(), planId: sub?.planId || 'FREE_TRIAL' });
      return res.status(200).json({ token, user });
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }

  static async register(req, res) {
    const transaction = await sequelize.transaction();
    try {
      const { companyName, siret, admin, planId } = req.body;
      const tenant = await Tenant.create({
        name: companyName,
        siret,
        domain: `${companyName.toLowerCase().replace(/\s+/g, '-')}-${Date.now().toString().slice(-4)}.gestock.pro`,
        paymentStatus: planId === 'FREE_TRIAL' ? 'TRIAL' : 'PENDING',
        isActive: true,
        plan: planId // Stockage direct pour info
      }, { transaction });

      const user = await User.create({
        email: admin.email,
        password: admin.password,
        name: admin.name || 'Propriétaire',
        role: 'ADMIN',
        roles: ['ADMIN'], 
        tenantId: tenant.id
      }, { transaction });

      await Subscription.create({
        tenantId: tenant.id,
        planId: planId || 'FREE_TRIAL',
        status: planId === 'FREE_TRIAL' ? 'TRIAL' : 'PENDING',
        nextBillingDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)
      }, { transaction });

      await transaction.commit();
      const token = AuthService.generateToken({ ...user.toJSON(), planId });

      return res.status(201).json({ 
        token,
        user: { id: user.id, name: user.name, role: 'ADMIN', roles: ['ADMIN'], tenantId: tenant.id, planId },
        subscription: { planId: planId || 'FREE_TRIAL', status: planId === 'FREE_TRIAL' ? 'TRIAL' : 'PENDING' }
      });
    } catch (error) {
      if (transaction) await transaction.rollback();
      return res.status(500).json({ error: 'RegisterError', message: error.message });
    }
  }

  static async listUsers(req, res) {
    try {
      const users = await User.findAll({ where: { tenantId: req.user.tenantId } });
      return res.status(200).json(users);
    } catch (error) { return res.status(500).json({ error: error.message }); }
  }

  static async createUser(req, res) {
    try {
      const user = await User.create({ ...req.body, tenantId: req.user.tenantId });
      return res.status(201).json(user);
    } catch (error) { return res.status(400).json({ error: error.message }); }
  }

  static async updateUser(req, res) {
    try {
      const user = await User.findOne({ where: { id: req.params.id, tenantId: req.user.tenantId } });
      if (!user) return res.status(404).json({ error: 'User not found' });
      await user.update(req.body);
      return res.status(200).json(user);
    } catch (error) { return res.status(400).json({ error: error.message }); }
  }

  static async deleteUser(req, res) {
    try {
      const user = await User.findOne({ where: { id: req.params.id, tenantId: req.user.tenantId } });
      if (!user) return res.status(404).json({ error: 'User not found' });
      await user.destroy();
      return res.status(204).send();
    } catch (error) { return res.status(500).json({ error: error.message }); }
  }

  static async resetUserPassword(req, res) {
    try {
      const { id } = req.params;
      const { newPassword } = req.body;
      const user = await User.findOne({ where: { id, tenantId: req.user.tenantId } });
      if (!user) return res.status(404).json({ error: 'UserNotFound' });
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash(newPassword, salt);
      await user.update({ password: hashedPassword });
      return res.status(200).json({ message: 'OK' });
    } catch (error) { return res.status(500).json({ error: error.message }); }
  }

  static async toggleMFA(req, res) {
    try {
      const { id } = req.params;
      const user = await User.findOne({ where: { id, tenantId: req.user.tenantId } });
      if (!user) return res.status(404).json({ error: 'UserNotFound' });
      user.mfaEnabled = !user.mfaEnabled;
      await user.save();
      return res.status(200).json({ mfaEnabled: user.mfaEnabled });
    } catch (error) { return res.status(500).json({ error: error.message }); }
  }

  static async superAdminLogin(req, res) {
    try {
      const emailInput = (req.body.email || '').toLowerCase().trim();
      const passwordInput = (req.body.password || '').trim();
      const admin = await Administrator.findOne({ where: { email: emailInput } });
      if (!admin || !await bcrypt.compare(passwordInput, admin.password)) {
        return res.status(401).json({ error: 'Accès refusé' });
      }
      const token = AuthService.generateToken({ id: admin.id, name: admin.name, tenantId: 'SYSTEM', roles: ['SUPER_ADMIN'] });
      return res.status(200).json({ token, user: { id: admin.id, name: admin.name, role: 'SUPER_ADMIN', roles: ['SUPER_ADMIN'], tenantId: 'SYSTEM' } });
    } catch (error) { return res.status(500).json({ error: error.message }); }
  }
}
