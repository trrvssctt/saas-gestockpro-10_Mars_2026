
import { Tenant, User, Subscription, Plan, Payment, AuditLog } from '../models/index.js';
import { sequelize } from '../config/database.js';
import { Op, fn, col } from 'sequelize';
import crypto from 'crypto';

export class AdminController {
  /**
   * Dashboard Global : Stats, Revenus et Alertes
   */
  static async getGlobalDashboard(req, res) {
    try {
      const totalTenants = await Tenant.count();
      const activeTenants = await Tenant.count({ where: { isActive: true } });
      const pendingSub = await Subscription.count({ where: { status: 'PENDING' } });
      const latePayments = await Tenant.count({ where: { paymentStatus: 'LATE' } });
      
      const tenantsWithSubscriptions = await Tenant.findAll({
        where: { isActive: true },
        include: [{ 
          model: Subscription, 
          as: 'subscription',
          include: [{ model: Plan, as: 'planDetails', attributes: ['priceMonthly'] }]
        }]
      });
      
      const mrr = tenantsWithSubscriptions.reduce((sum, t) => {
        const price = parseFloat(t.subscription?.planDetails?.priceMonthly) || 0;
        return sum + price;
      }, 0);

      const revenueStats = await Payment.findAll({
        where: { 
          paymentDate: { [Op.gt]: new Date(new Date().setMonth(new Date().getMonth() - 6)) },
          saleId: null 
        },
        attributes: [
          [fn('date_trunc', 'month', col('payment_date')), 'month'],
          [fn('SUM', col('amount')), 'total']
        ],
        group: [fn('date_trunc', 'month', col('payment_date'))],
        order: [[fn('date_trunc', 'month', col('payment_date')), 'ASC']]
      });

      const pendingValidations = await Subscription.findAll({
        where: { status: 'PENDING' },
        include: [{ model: Tenant, attributes: ['name'] }],
        limit: 10
      });

      return res.status(200).json({ 
        stats: { totalTenants, activeTenants, pendingSub, latePayments, mrr },
        revenueStats: revenueStats || [],
        pendingValidations: pendingValidations || []
      });
    } catch (error) {
      console.error("[KERNEL ADMIN DASHBOARD ERROR]:", error);
      return res.status(500).json({ error: error.name, message: error.message });
    }
  }

  /**
   * Liste enrichie des comptes
   */
  static async listTenants(req, res) {
    try {
      const tenants = await Tenant.findAll({
        order: [['createdAt', 'DESC']],
        include: [
          { 
            model: Subscription, 
            as: 'subscription',
            include: [{ model: Plan, as: 'planDetails' }]
          }
        ]
      });
      
      const enriched = await Promise.all(tenants.map(async (t) => {
        const userCount = await User.count({ where: { tenantId: t.id } });
        return { 
          ...t.toJSON(), 
          userCount,
          planName: t.subscription?.planDetails?.name || 'SANS_PLAN',
          planMaxUsers: t.subscription?.planDetails?.maxUsers || 0,
          isUpToDate: t.paymentStatus === 'UP_TO_DATE' || t.paymentStatus === 'TRIAL'
        };
      }));

      return res.status(200).json(enriched);
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }

  /**
   * Détails d'une souscription spécifique (Registry Billing)
   */
  static async getTenantBillingDetails(req, res) {
    try {
      const { id } = req.params;
      const tenant = await Tenant.findByPk(id, {
        include: [
          { 
            model: Subscription, 
            as: 'subscription',
            include: [{ model: Plan, as: 'planDetails' }]
          }
        ]
      });

      if (!tenant) return res.status(404).json({ error: 'Instance non trouvée' });

      const payments = await Payment.findAll({
        where: { tenantId: id, saleId: null },
        order: [['paymentDate', 'DESC']]
      });

      const userCount = await User.count({ where: { tenantId: id } });

      return res.status(200).json({
        tenant,
        payments,
        stats: { userCount }
      });
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }

  /**
   * Kill-Switch (Correction de l'audit)
   */
  static async toggleTenantLock(req, res) {
    try {
      const { id } = req.params;
      const tenant = await Tenant.findByPk(id);
      if (!tenant) return res.status(404).json({ error: 'Tenant non trouvé' });

      await tenant.update({ isActive: !tenant.isActive });
      
      // FIX: Inclusion obligatoire du user_id du SuperAdmin pour l'audit
      await AuditLog.create({
        tenantId: id,
        userId: req.user.id, // L'ID du SuperAdmin connecté
        userName: req.user.name || 'MASTER_ADMIN',
        action: tenant.isActive ? 'TENANT_UNLOCKED' : 'TENANT_LOCKED',
        resource: `Tenant: ${tenant.name} (${tenant.domain})`,
        severity: 'HIGH',
        sha256Signature: crypto.createHash('sha256').update(`LOCK_ACTION:${id}:${Date.now()}`).digest('hex')
      });

      return res.status(200).json(tenant);
    } catch (error) {
      console.error("[TOGGLE LOCK ERROR]:", error);
      return res.status(500).json({ error: error.name, message: error.message });
    }
  }

  static async listPlans(req, res) {
    try {
      const plans = await Plan.findAll({ order: [['priceMonthly', 'ASC']] });
      return res.status(200).json(plans);
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }

  static async createPlan(req, res) {
    try {
      const plan = await Plan.create(req.body);
      return res.status(201).json(plan);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  }

  static async updatePlan(req, res) {
    try {
      const plan = await Plan.findByPk(req.params.id);
      if (!plan) return res.status(404).json({ error: 'Plan non trouvé' });
      await plan.update(req.body);
      return res.status(200).json(plan);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  }

  static async deletePlan(req, res) {
    try {
      const plan = await Plan.findByPk(req.params.id);
      if (!plan) return res.status(404).json({ error: 'Plan non trouvé' });
      await plan.update({ isActive: false });
      return res.status(200).json({ message: 'Plan désactivé.' });
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }

  static async sendEmailToOwner(req, res) {
    try {
      return res.status(200).json({ message: 'Email envoyé' });
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }
}
