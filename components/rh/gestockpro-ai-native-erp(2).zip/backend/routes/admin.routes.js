
import { Router } from 'express';
import { AdminController } from '../controllers/AdminController.js';
import { checkRole } from '../middlewares/rbac.js';

const router = Router();

router.use(checkRole(['SUPER_ADMIN']));

// Dashboard
router.get('/dashboard', AdminController.getGlobalDashboard);

// Tenants
router.get('/tenants', AdminController.listTenants);
router.get('/tenants/:id/billing', AdminController.getTenantBillingDetails); // Détails Facturation
router.post('/tenants/:id/toggle-lock', AdminController.toggleTenantLock);

// Plans CRUD
router.get('/plans', AdminController.listPlans);
router.post('/plans', AdminController.createPlan);
router.put('/plans/:id', AdminController.updatePlan);
router.delete('/plans/:id', AdminController.deletePlan);

// Communication
router.post('/email/send', AdminController.sendEmailToOwner);

export default router;
