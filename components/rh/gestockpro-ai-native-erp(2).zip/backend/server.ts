
import express from 'express';
import cors from 'cors';
import { connectDB } from './config/database';
import apiRoutes from './routes/api';
import { errorHandler } from './middlewares/errorHandler';

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration Middlewares de base
app.use(cors() as any);
app.use(express.json() as any);

// Routes API v1
app.use('/api', apiRoutes as any);

// Health Check
app.get('/health', (req, res) => res.send('GeStockPro Kernel Online'));

// Gestionnaire d'erreurs (doit être en dernier)
app.use(errorHandler as any);

app.listen(PORT, async () => {
  await connectDB();
  console.log(`🚀 GeStockPro API running on http://localhost:${PORT}`);
});
