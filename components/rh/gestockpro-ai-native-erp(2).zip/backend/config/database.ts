
import { Sequelize } from 'sequelize';

export const sequelize = new Sequelize('gestionapp_GeSTOCKpro', 'gestionapp', 'Dianka16', {
  host: 'postgresql-gestionapp.alwaysdata.net',
  port: 5432,
  dialect: 'postgres',
  logging: false,
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false
    }
  }
});

export const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ PostgreSQL Connected: AlwaysData Infrastructure');
  } catch (error) {
    console.error('❌ Database Connection Error:', error);
  }
};
