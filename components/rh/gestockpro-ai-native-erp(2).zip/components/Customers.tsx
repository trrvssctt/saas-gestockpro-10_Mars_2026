
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Users, Search, Plus, Mail, Phone, Building2, Eye, Edit3, Trash2, X,
  ChevronRight, Star, UserCheck, AlertCircle, RefreshCw, ArrowRight, Save, Loader2, MapPin,
  History, DollarSign, FileText, Clock, Lock, ShieldCheck, TrendingUp, BarChart3,
  CreditCard, Activity, CheckCircle2, Calendar, Info, ShieldAlert
} from 'lucide-react';
import { Customer, UserRole, User, SubscriptionPlan } from '../types';
import { authBridge, BASIC_LIMITS } from '../services/authBridge';
import { apiClient } from '../services/api';

interface CustomersProps {
  user: User;
  currency: string;
  plan?: SubscriptionPlan;
}

const Customers: React.FC<CustomersProps> = ({ user, currency, plan }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState<Customer | null>(null);
  const [showDetailModal, setShowDetailModal] = useState<Customer | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  const [formData, setFormData] = useState({
    companyName: '', email: '', phone: '', mainContact: '', 
    billingAddress: '', paymentTerms: 30, maxCreditLimit: 5000
  });

  const canModify = authBridge.canPerform(user, 'EDIT', 'customers');
  
  // 🔒 LOGIQUE DE LIMITE PLAN BASIC
  const isLimitReached = (user.planId === 'BASIC' && customers.length >= BASIC_LIMITS.MAX_CUSTOMERS) ||
                        (user.planId === 'FREE_TRIAL' && customers.length >= 1);

  const fetchData = async () => {
    setLoading(true);
    try {
      const data = await apiClient.get('/customers');
      setCustomers(data || []);
    } catch (err: any) {
      setError(err.message || "Erreur de liaison Kernel.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLimitReached) {
      setError(user.planId === 'BASIC' ? "Limite du plan Basic atteinte : maximum 5 clients." : "Limite du plan atteinte.");
      return;
    }
    setActionLoading(true);
    try {
      const data = await apiClient.post('/customers', formData);
      setCustomers([data, ...customers]);
      setShowCreateModal(false);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Échec de l'enregistrement.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showEditModal) return;
    setActionLoading(true);
    try {
      const updated = await apiClient.put(`/customers/${showEditModal.id}`, formData);
      setCustomers(prev => prev.map(c => c.id === updated.id ? updated : c));
      setShowEditModal(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const filteredCustomers = customers.filter(c => 
    (c.companyName || '').toLowerCase().includes(search.toLowerCase()) || 
    (c.email || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter flex items-center gap-3 uppercase">
            <Users className="text-indigo-600" size={32} /> Répertoire Partenaires
          </h2>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] mt-1">
            {user.planId === 'BASIC' ? `Plan Basic : ${customers.length} / ${BASIC_LIMITS.MAX_CUSTOMERS} clients` : 'Registre Clients'}
          </p>
        </div>
        {canModify && (
          isLimitReached ? (
            <div className="flex items-center gap-3 px-6 py-4 bg-rose-50 text-rose-600 rounded-2xl border border-rose-100 text-[10px] font-black uppercase tracking-widest shadow-sm">
              <Lock size={16} /> Quota {user.planId === 'BASIC' ? '5 clients' : 'plan'} atteint
            </div>
          ) : (
            <button 
              onClick={() => { setFormData({ companyName: '', email: '', phone: '', mainContact: '', billingAddress: '', paymentTerms: 30, maxCreditLimit: 5000 }); setShowCreateModal(true); setError(null); }}
              className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black hover:bg-indigo-600 transition-all shadow-xl flex items-center gap-3 text-xs uppercase tracking-widest"
            >
              <Plus size={18} /> CRÉER UN CLIENT
            </button>
          )
        )}
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-[10px] font-black uppercase flex items-center gap-3 animate-in shake">
          <AlertCircle size={16}/> {error}
        </div>
      )}

      <div className="bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm">
        <div className="relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input type="text" placeholder="Rechercher par nom, email..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full bg-slate-50 border-none rounded-2xl pl-14 pr-4 py-4 text-sm font-bold outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all shadow-inner" />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => <div key={i} className="h-64 bg-white rounded-[2.5rem] animate-pulse border border-slate-100"></div>)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredCustomers.map(customer => (
            <div key={customer.id} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all p-8 flex flex-col group relative overflow-hidden">
                <div className="flex justify-between items-start mb-6">
                  <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-black text-xl uppercase shadow-inner group-hover:scale-110 transition-transform">
                    {(customer.companyName || 'C').charAt(0)}
                  </div>
                  <span className={`px-2 py-1 rounded-lg text-[7px] font-black uppercase tracking-widest border ${customer.healthStatus === 'GOOD' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
                    {customer.healthStatus}
                  </span>
                </div>
                <h3 className="font-black text-slate-900 text-lg uppercase truncate">{customer.companyName || 'Client'}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-2 truncate flex items-center gap-2"><Mail size={12}/> {customer.email}</p>
                <div className="mt-8 pt-6 border-t flex justify-between gap-2">
                   <button onClick={() => setShowDetailModal(customer)} className="text-[10px] font-black text-indigo-600 uppercase flex items-center gap-2 hover:bg-indigo-50 px-4 py-2 rounded-xl transition-all">VOIR <Eye size={14}/></button>
                   {canModify && (
                     <button onClick={() => { 
                       // Fix: explicitly map customer properties to formData to ensure type safety and handle optional fields
                       setFormData({
                         companyName: customer.companyName,
                         email: customer.email,
                         phone: customer.phone,
                         mainContact: customer.mainContact,
                         billingAddress: customer.billingAddress,
                         paymentTerms: customer.paymentTerms,
                         maxCreditLimit: customer.maxCreditLimit || 5000
                       }); 
                       setShowEditModal(customer); 
                     }} className="p-2 text-slate-300 hover:text-amber-500 transition-colors">
                       <Edit3 size={18}/>
                     </button>
                   )}
                </div>
            </div>
          ))}
        </div>
      )}

      {(showCreateModal || showEditModal) && (
        <div className="fixed inset-0 z-[700] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md">
          <div className="bg-white w-full max-w-xl rounded-[3.5rem] shadow-2xl p-10 animate-in zoom-in-95">
             <h3 className="text-xl font-black uppercase mb-8">{showEditModal ? 'Révision Fiche' : 'Nouveau Client'}</h3>
             {error && <div className="p-4 bg-rose-50 text-rose-600 rounded-xl text-[10px] font-black uppercase mb-6">{error}</div>}
             <form onSubmit={showEditModal ? handleUpdate : handleCreate} className="space-y-6">
                <input type="text" required value={formData.companyName} onChange={e => setFormData({...formData, companyName: e.target.value})} className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 text-sm font-black" placeholder="Raison Sociale" />
                <input type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 text-sm font-black" placeholder="Email" />
                <button type="submit" disabled={actionLoading} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase shadow-xl">
                  {actionLoading ? <RefreshCw className="animate-spin" /> : "SCELLER"}
                </button>
             </form>
             <button onClick={() => { setShowCreateModal(false); setShowEditModal(null); setError(null); }} className="w-full mt-4 text-[10px] font-black text-slate-400 uppercase">Annuler</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;
