
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Settings, 
  Play, 
  ClipboardList, 
  TrendingUp, 
  CreditCard, 
  FileCheck, 
  Download, 
  Plus, 
  Search, 
  Filter, 
  DollarSign, 
  Calendar, 
  CheckCircle2, 
  AlertCircle,
  History,
  PieChart,
  Globe,
  Briefcase,
  Users,
  Layers,
  FileText,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import HRModal from './HRModal';

interface PayrollManagementProps {
  onNavigate: (tab: string, meta?: any) => void;
}

const PayrollManagement: React.FC<PayrollManagementProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState('generation');
  const [isGenModalOpen, setIsGenModalOpen] = useState(false);
  const [isAdvanceModalOpen, setIsAdvanceModalOpen] = useState(false);
  const [isSettingModalOpen, setIsSettingModalOpen] = useState(false);
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');

  const tabs = [
    { id: 'generation', label: 'Génération Paie', icon: <Play size={16} /> },
    { id: 'slips', label: 'Bulletins', icon: <ClipboardList size={16} /> },
    { id: 'advances', label: 'Avances & Primes', icon: <TrendingUp size={16} /> },
    { id: 'declarations', label: 'Déclarations', icon: <FileCheck size={16} /> },
    { id: 'settings', label: 'Paramétrage', icon: <Settings size={16} /> },
  ];

  const handleRunPayroll = (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenModalOpen(false);
    setAlertMessage('Traitement de la paie lancé avec succès');
    setShowSuccessAlert(true);
    setTimeout(() => setShowSuccessAlert(false), 3000);
  };

  const handleSaveAdvance = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAdvanceModalOpen(false);
    setAlertMessage('Demande enregistrée et en attente de validation');
    setShowSuccessAlert(true);
    setTimeout(() => setShowSuccessAlert(false), 3000);
  };

  const handleSaveSetting = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSettingModalOpen(false);
    setAlertMessage('Paramètres de paie mis à jour');
    setShowSuccessAlert(true);
    setTimeout(() => setShowSuccessAlert(false), 3000);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      {/* Success Alert */}
      <AnimatePresence>
        {showSuccessAlert && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-8 left-1/2 -translate-x-1/2 z-[200] bg-emerald-500 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-4 font-black uppercase text-[10px] tracking-widest"
          >
            <CheckCircle2 size={20} /> {alertMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => onNavigate('rh')}
            className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">Gestion de la Paie</h1>
            <p className="text-slate-500 font-medium uppercase text-[10px] tracking-[0.3em]">Traitement des salaires & charges</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-6 py-3 bg-white border border-slate-100 text-slate-900 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <History size={16} /> Historique
          </button>
          <button 
            onClick={() => setIsGenModalOpen(true)}
            className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95"
          >
            <Play size={16} /> Lancer Traitement
          </button>
        </div>
      </div>

      {/* Generation Modal */}
      <HRModal 
        isOpen={isGenModalOpen} 
        onClose={() => setIsGenModalOpen(false)} 
        title="Lancer le traitement de la paie"
        size="md"
        footer={
          <div className="flex justify-end gap-4">
            <button 
              onClick={() => setIsGenModalOpen(false)}
              className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all"
            >
              Annuler
            </button>
            <button 
              onClick={handleRunPayroll}
              className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl"
            >
              Démarrer le Traitement
            </button>
          </div>
        }
      >
        <div className="space-y-6">
          <div className="p-6 bg-indigo-50 rounded-[2rem] border border-indigo-100">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-500 shadow-sm">
                <Calendar size={24} />
              </div>
              <div>
                <p className="text-sm font-black text-slate-900 uppercase tracking-tight">Période : Octobre 2024</p>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">12 employés concernés</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Le traitement va calculer les salaires bruts, les cotisations sociales, les impôts et générer les bulletins de paie pour tous les employés actifs.
            </p>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <input type="checkbox" id="confirm" className="w-5 h-5 rounded border-slate-200 text-indigo-600 focus:ring-indigo-500" />
              <label htmlFor="confirm" className="text-xs font-bold text-slate-700">Je confirme avoir vérifié les absences et les primes du mois.</label>
            </div>
          </div>
        </div>
      </HRModal>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-[2rem] w-fit overflow-x-auto no-scrollbar">
        {tabs.map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-6 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === tab.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div 
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'generation' && (
            <div className="space-y-8">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                  <div className="flex items-center justify-between mb-10">
                    <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                      <Calendar className="text-indigo-500" /> Paie en cours : Octobre 2024
                    </h3>
                    <span className="px-4 py-1.5 bg-amber-50 text-amber-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-amber-100">En préparation</span>
                  </div>
                  
                  <div className="space-y-8">
                    <div className="grid sm:grid-cols-3 gap-8">
                      <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Effectif à payer</p>
                        <p className="text-3xl font-black text-slate-900">124</p>
                      </div>
                      <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Masse Brute Est.</p>
                        <p className="text-3xl font-black text-slate-900">58.4M</p>
                      </div>
                      <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Charges Est.</p>
                        <p className="text-3xl font-black text-slate-900">12.8M</p>
                      </div>
                    </div>

                    <div className="p-8 bg-indigo-50 rounded-[2.5rem] border border-indigo-100 flex items-center justify-between">
                      <div className="flex items-center gap-6">
                        <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
                          <Play size={28} />
                        </div>
                        <div>
                          <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight">Prêt pour le calcul global</h4>
                          <p className="text-xs font-medium text-slate-500">Tous les éléments variables (primes, absences) ont été importés.</p>
                        </div>
                      </div>
                      <button className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200">
                        Calculer la Paie
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900 p-10 rounded-[3rem] text-white relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-3xl rounded-full"></div>
                  <h3 className="text-sm font-black uppercase tracking-widest mb-8 flex items-center gap-3">
                    <AlertCircle className="text-amber-400" /> Anomalies Détectées
                  </h3>
                  <div className="space-y-6 relative z-10">
                    {[
                      { emp: 'Jean Koffi', issue: 'Salaire de base non défini', type: 'CRITICAL' },
                      { emp: 'Moussa Diop', issue: 'Prime exceptionnelle > 50% salaire', type: 'WARNING' },
                      { emp: 'Awa Ndiaye', issue: 'Contrat expiré le 30/09', type: 'CRITICAL' },
                    ].map((anomaly, i) => (
                      <div key={i} className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/10">
                        <div className={`w-2 h-2 rounded-full mt-1.5 ${anomaly.type === 'CRITICAL' ? 'bg-rose-500' : 'bg-amber-500'}`}></div>
                        <div>
                          <p className="text-xs font-black uppercase tracking-tight">{anomaly.emp}</p>
                          <p className="text-[10px] text-slate-400 font-medium">{anomaly.issue}</p>
                        </div>
                      </div>
                    ))}
                    <div className="pt-4">
                      <button className="w-full py-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border border-white/10">
                        Résoudre les anomalies
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-8 flex items-center gap-3">
                  <Users className="text-indigo-500" /> Détail par Employé
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-50">
                        <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Employé</th>
                        <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Salaire Base</th>
                        <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Primes</th>
                        <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Retenues</th>
                        <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Net à Payer</th>
                        <th className="text-right py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { name: 'Moussa Diop', base: '1,500,000', bonus: '150,000', deduct: '330,000', net: '1,320,000' },
                        { name: 'Awa Ndiaye', base: '1,200,000', bonus: '0', deduct: '240,000', net: '960,000' },
                        { name: 'Jean Koffi', base: '800,000', bonus: '50,000', deduct: '170,000', net: '680,000' },
                      ].map((row, i) => (
                        <tr key={i} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                          <td className="py-6">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-slate-100 rounded-xl overflow-hidden">
                                <img src={`https://picsum.photos/seed/${i+100}/100/100`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              </div>
                              <span className="text-sm font-bold text-slate-900">{row.name}</span>
                            </div>
                          </td>
                          <td className="py-6 text-sm font-bold text-slate-900">{row.base}</td>
                          <td className="py-6 text-sm font-bold text-emerald-600">+{row.bonus}</td>
                          <td className="py-6 text-sm font-bold text-rose-600">-{row.deduct}</td>
                          <td className="py-6 text-sm font-black text-slate-900">{row.net} F CFA</td>
                          <td className="py-6 text-right">
                            <button className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm">
                              <Search size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-10 flex items-center gap-3">
                  <Globe className="text-indigo-500" /> Paramétrage Pays (Sénégal)
                </h3>
                <div className="space-y-8">
                  <div className="grid sm:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Charges Sociales (Employeur)</label>
                      <div className="flex items-center gap-3">
                        <input type="text" defaultValue="18.5" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                        <span className="font-black text-slate-400">%</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Charges Sociales (Salarié)</label>
                      <div className="flex items-center gap-3">
                        <input type="text" defaultValue="8.2" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                        <span className="font-black text-slate-400">%</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Devise de Paie</label>
                    <select className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm">
                      <option>F CFA (XOF)</option>
                      <option>Euro (€)</option>
                      <option>US Dollar ($)</option>
                    </select>
                  </div>
                  <div className="pt-6">
                    <button 
                      onClick={handleSaveSetting}
                      className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl active:scale-95"
                    >
                      Enregistrer les paramètres pays
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                  <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                    <Layers className="text-indigo-500" /> Rubriques de Paie
                  </h3>
                  <button 
                    onClick={() => setIsSettingModalOpen(true)}
                    className="w-10 h-10 bg-slate-50 text-slate-900 rounded-xl flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all"
                  >
                    <Plus size={18} />
                  </button>
                </div>

                {/* Rubrique Modal */}
                <HRModal 
                  isOpen={isSettingModalOpen} 
                  onClose={() => setIsSettingModalOpen(false)} 
                  title="Nouvelle Rubrique de Paie"
                  size="md"
                  footer={
                    <div className="flex justify-end gap-4">
                      <button onClick={() => setIsSettingModalOpen(false)} className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all">Annuler</button>
                      <button onClick={handleSaveSetting} className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl">Ajouter</button>
                    </div>
                  }
                >
                  <form className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nom de la Rubrique</label>
                      <input type="text" placeholder="Ex: Prime de Panier" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Type</label>
                        <select className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm">
                          <option>Gain (Earning)</option>
                          <option>Retenue (Deduction)</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Catégorie</label>
                        <select className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm">
                          <option>Indemnité</option>
                          <option>Prime</option>
                          <option>Charge Sociale</option>
                          <option>Taxe</option>
                        </select>
                      </div>
                    </div>
                  </form>
                </HRModal>
                <div className="space-y-4">
                  {[
                    { name: 'Salaire de Base', type: 'EARNING', cat: 'BASE_SALARY' },
                    { name: 'Prime de Transport', type: 'EARNING', cat: 'ALLOWANCE' },
                    { name: 'Indemnité de Logement', type: 'EARNING', cat: 'ALLOWANCE' },
                    { name: 'Retenue IPRES', type: 'DEDUCTION', cat: 'SOCIAL_CHARGE' },
                    { name: 'Impôt sur le Revenu', type: 'DEDUCTION', cat: 'TAX' },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex items-center gap-4">
                        <div className={`w-2 h-2 rounded-full ${item.type === 'EARNING' ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{item.name}</p>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.cat}</p>
                        </div>
                      </div>
                      <button className="text-slate-400 hover:text-slate-900">
                        <Settings size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'slips' && (
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                  <ClipboardList className="text-indigo-500" /> Consultation des Bulletins
                </h3>
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input type="text" placeholder="Rechercher..." className="pl-10 pr-4 py-2 bg-slate-50 border-none rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500" />
                  </div>
                  <select className="bg-slate-50 border-none rounded-xl font-black text-[10px] uppercase tracking-widest text-slate-600 px-4 py-2">
                    <option>Octobre 2024</option>
                    <option>Septembre 2024</option>
                  </select>
                </div>
              </div>
              
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1,2,3,4,5,6].map(i => (
                  <div key={i} className="p-6 bg-slate-50 rounded-[2.5rem] border border-slate-100 hover:bg-white hover:shadow-xl transition-all group">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-500 shadow-sm group-hover:scale-110 transition-transform">
                        <FileText size={24} />
                      </div>
                      <div>
                        <p className="text-sm font-black text-slate-900 uppercase tracking-tight">Employé #{i}</p>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Octobre 2024</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                      <span className="text-xs font-black text-slate-900">1,250,000 F</span>
                      <button className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 hover:bg-slate-900 hover:text-white transition-all shadow-sm">
                        <Download size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'advances' && (
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                  <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                    <CreditCard className="text-indigo-500" /> Avances sur Salaire
                  </h3>
                  <button 
                    onClick={() => setIsAdvanceModalOpen(true)}
                    className="w-10 h-10 bg-slate-50 text-slate-900 rounded-xl flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all"
                  >
                    <Plus size={18} />
                  </button>
                </div>

                {/* Advance Modal */}
                <HRModal 
                  isOpen={isAdvanceModalOpen} 
                  onClose={() => setIsAdvanceModalOpen(false)} 
                  title="Nouvelle Demande d'Avance"
                  size="md"
                  footer={
                    <div className="flex justify-end gap-4">
                      <button onClick={() => setIsAdvanceModalOpen(false)} className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all">Annuler</button>
                      <button onClick={handleSaveAdvance} className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl">Soumettre</button>
                    </div>
                  }
                >
                  <form className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Employé</label>
                      <select className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm">
                        <option>Moussa Diop</option>
                        <option>Awa Ndiaye</option>
                        <option>Jean Koffi</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Montant (F CFA)</label>
                      <input type="number" placeholder="Ex: 200000" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Date de Remboursement Souhaitée</label>
                      <input type="date" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                    </div>
                  </form>
                </HRModal>
                <div className="space-y-4">
                  {[
                    { name: 'Jean Koffi', amount: '150,000', date: '12/10/2024', status: 'PENDING' },
                    { name: 'Awa Ndiaye', amount: '200,000', date: '05/10/2024', status: 'APPROVED' },
                  ].map((adv, i) => (
                    <div key={i} className="flex items-center justify-between p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-indigo-500 shadow-sm">
                          <CreditCard size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{adv.name}</p>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{adv.amount} F CFA • {adv.date}</p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${adv.status === 'APPROVED' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                        {adv.status === 'APPROVED' ? 'Validé' : 'En attente'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                  <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                    <TrendingUp className="text-indigo-500" /> Primes Exceptionnelles
                  </h3>
                  <button className="w-10 h-10 bg-slate-50 text-slate-900 rounded-xl flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all">
                    <Plus size={18} />
                  </button>
                </div>
                <div className="space-y-4">
                  {[
                    { name: 'Moussa Diop', amount: '150,000', type: 'PERFORMANCE', date: '15/10/2024' },
                    { name: 'Equipe IT', amount: '500,000', type: 'EXCEPTIONAL', date: '10/10/2024' },
                  ].map((prime, i) => (
                    <div key={i} className="flex items-center justify-between p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-500 shadow-sm">
                          <TrendingUp size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{prime.name}</p>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{prime.amount} F CFA • {prime.type}</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{prime.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'declarations' && (
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-10">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                  <FileCheck className="text-indigo-500" /> Déclarations Sociales & Fiscales
                </h3>
                <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95">
                  <Plus size={16} /> Nouvelle Déclaration
                </button>
              </div>
              <div className="space-y-6">
                {[
                  { name: 'Déclaration IPRES - Octobre 2024', type: 'SOCIAL', status: 'READY', date: '25/10/2024' },
                  { name: 'Déclaration CSS - Octobre 2024', type: 'SOCIAL', status: 'READY', date: '25/10/2024' },
                  { name: 'VRS (Impôts sur Salaires) - Septembre 2024', type: 'FISCAL', status: 'FILED', date: '15/10/2024' },
                ].map((decl, i) => (
                  <div key={i} className="flex items-center justify-between p-6 bg-slate-50 rounded-[2.5rem] border border-slate-100 hover:bg-white hover:shadow-xl transition-all group">
                    <div className="flex items-center gap-6">
                      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-indigo-500 shadow-sm group-hover:scale-110 transition-transform">
                        <FileCheck size={28} />
                      </div>
                      <div>
                        <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{decl.name}</p>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{decl.type} • {decl.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${decl.status === 'FILED' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                        {decl.status === 'FILED' ? 'Déposé' : 'Prêt'}
                      </span>
                      <button className="px-6 py-3 bg-white border border-slate-100 text-slate-900 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all shadow-sm">
                        Générer Rapport
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default PayrollManagement;
