
import React from 'react';
import { 
  ArrowLeft, 
  Users, 
  GitPullRequest, 
  Download, 
  Plus, 
  Search, 
  Filter, 
  ChevronDown, 
  ChevronRight,
  User,
  Briefcase,
  Layers
} from 'lucide-react';
import { MOCK_EMPLOYEES } from '../../constants';

interface OrgChartProps {
  onNavigate: (tab: string, meta?: any) => void;
}

const OrgChart: React.FC<OrgChartProps> = ({ onNavigate }) => {
  // Simple hierarchical structure for mock
  const ceo = {
    id: 'E2',
    name: 'Awa Ndiaye',
    role: 'HR Manager / Acting CEO',
    dept: 'Executive',
    children: [
      {
        id: 'E1',
        name: 'Moussa Diop',
        role: 'Senior Developer',
        dept: 'IT',
        children: []
      },
      {
        id: 'E3',
        name: 'Jean Koffi',
        role: 'Sales Representative',
        dept: 'Sales',
        children: []
      }
    ]
  };

  const renderNode = (node: any) => (
    <div key={node.id} className="flex flex-col items-center">
      <div className="relative p-6 bg-white rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all duration-500 group cursor-pointer w-64 text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-[1.5rem] overflow-hidden mx-auto mb-4 border-4 border-white shadow-md group-hover:scale-110 transition-transform">
          <img src={`https://picsum.photos/seed/${node.id}/100/100`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        </div>
        <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight mb-1">{node.name}</h4>
        <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-3">{node.role}</p>
        <div className="flex items-center justify-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 py-1 px-3 rounded-full">
          <Layers size={10} /> {node.dept}
        </div>
      </div>
      
      {node.children.length > 0 && (
        <div className="flex flex-col items-center">
          <div className="w-px h-12 bg-slate-200"></div>
          <div className="flex gap-12 relative">
            {/* Horizontal line connecting children */}
            {node.children.length > 1 && (
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[calc(100%-16rem)] h-px bg-slate-200"></div>
            )}
            {node.children.map((child: any) => (
              <div key={child.id} className="flex flex-col items-center">
                <div className="w-px h-8 bg-slate-200"></div>
                {renderNode(child)}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => onNavigate('rh')}
            className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">Organigramme</h1>
            <p className="text-slate-500 font-medium uppercase text-[10px] tracking-[0.3em]">Structure hiérarchique de l'entreprise</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-6 py-3 bg-white border border-slate-100 text-slate-900 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <Download size={16} /> Export PDF
          </button>
          <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95">
            <Plus size={16} /> Ajouter Niveau
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col md:flex-row gap-6 items-center">
        <div className="relative flex-grow w-full">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Rechercher un membre..." 
            className="w-full pl-14 pr-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium text-sm"
          />
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="flex items-center gap-2 bg-slate-50 px-6 py-4 rounded-2xl">
            <Filter size={18} className="text-slate-400" />
            <select className="bg-transparent border-none focus:ring-0 font-black text-[10px] uppercase tracking-widest text-slate-600">
              <option>Tous les Départements</option>
              <option>IT</option>
              <option>Sales</option>
            </select>
          </div>
        </div>
      </div>

      {/* Org Chart View */}
      <div className="bg-slate-50 p-20 rounded-[4rem] border border-slate-100 shadow-inner overflow-auto min-h-[600px] flex justify-center">
        <div className="w-fit">
          {renderNode(ceo)}
        </div>
      </div>
    </div>
  );
};

export default OrgChart;
