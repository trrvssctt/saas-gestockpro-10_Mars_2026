
import React, { useState } from 'react';
import { 
  Users, 
  FileText, 
  GitPullRequest, 
  FolderOpen, 
  CreditCard, 
  Settings, 
  Play, 
  ClipboardList, 
  TrendingUp, 
  Calendar, 
  Clock, 
  Award,
  ChevronRight,
  Plus,
  Search,
  Filter,
  Download,
  MoreVertical,
  UserPlus,
  Briefcase,
  Layers,
  ShieldCheck,
  History,
  FileCheck,
  DollarSign,
  PieChart,
  Activity
} from 'lucide-react';
import { motion } from 'framer-motion';

interface HRDashboardProps {
  onNavigate: (tab: string, meta?: any) => void;
}

const HRDashboard: React.FC<HRDashboardProps> = ({ onNavigate }) => {
  const [activeSection, setActiveSection] = useState<'admin' | 'payroll'>('admin');

  const adminModules = [
    { id: 'hr_employees', title: 'Employés', desc: 'Gestion administrative, fiches salariés, dossiers numériques.', icon: <Users />, color: 'bg-blue-500' },
    { id: 'hr_contracts', title: 'Contrats', desc: 'Gestion des contrats, renouvellements, périodes d\'essai.', icon: <FileText />, color: 'bg-indigo-500' },
    { id: 'hr_org', title: 'Organigramme', desc: 'Vue graphique hiérarchique et structurelle.', icon: <GitPullRequest />, color: 'bg-purple-500' },
    { id: 'hr_docs', title: 'Documents', desc: 'Gestion centralisée des documents employés (CNI, Diplômes).', icon: <FolderOpen />, color: 'bg-amber-500' },
  ];

  const payrollModules = [
    { id: 'hr_payroll_settings', title: 'Paramétrage', desc: 'Charges sociales, impôts, rubriques de paie.', icon: <Settings />, color: 'bg-slate-700' },
    { id: 'hr_payroll_gen', title: 'Génération Paie', desc: 'Calcul mensuel, validation globale, bulletins.', icon: <Play />, color: 'bg-emerald-600' },
    { id: 'hr_payroll_slips', title: 'Fiches de Paie', desc: 'Consultation et téléchargement des bulletins PDF.', icon: <ClipboardList />, color: 'bg-blue-600' },
    { id: 'hr_payroll_bonuses', title: 'Primes', desc: 'Gestion des primes exceptionnelles et de performance.', icon: <TrendingUp />, color: 'bg-rose-500' },
    { id: 'hr_payroll_advances', title: 'Avances', desc: 'Demandes d\'avances sur salaire et acomptes.', icon: <CreditCard />, color: 'bg-orange-500' },
    { id: 'hr_payroll_declarations', title: 'Déclarations', desc: 'Rapports sociaux et fiscaux officiels.', icon: <FileCheck />, color: 'bg-cyan-600' },
  ];

  const stats = [
    { label: 'Total Employés', value: '124', change: '+4 ce mois', icon: <Users /> },
    { label: 'Masse Salariale', value: '45.2M', change: '+2.1%', icon: <DollarSign /> },
    { label: 'Congés Actifs', value: '12', change: 'En cours', icon: <Calendar /> },
    { label: 'Performance Moy.', value: '88%', change: '+5%', icon: <Activity /> },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">Module RH & Paie</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-[0.3em]">Gestion du capital humain - Enterprise Edition</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95">
            <UserPlus size={16} /> Nouvel Employé
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-slate-50 text-slate-900 rounded-2xl flex items-center justify-center">
                {stat.icon}
              </div>
              <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full">
                {stat.change}
              </span>
            </div>
            <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest mb-1">{stat.label}</p>
            <p className="text-3xl font-black text-slate-900 tracking-tighter">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-[2rem] w-fit">
        <button 
          onClick={() => setActiveSection('admin')}
          className={`px-8 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all ${activeSection === 'admin' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Administration RH
        </button>
        <button 
          onClick={() => setActiveSection('payroll')}
          className={`px-8 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all ${activeSection === 'payroll' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Gestion de la Paie
        </button>
      </div>

      {/* Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {(activeSection === 'admin' ? adminModules : payrollModules).map((module, i) => (
          <motion.div 
            key={module.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => onNavigate(module.id)}
            className="group cursor-pointer"
          >
            <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 relative overflow-hidden h-full flex flex-col">
              <div className={`w-16 h-16 ${module.color} text-white rounded-[1.5rem] flex items-center justify-center mb-8 shadow-xl group-hover:scale-110 transition-transform duration-500`}>
                {React.cloneElement(module.icon as React.ReactElement, { size: 32 })}
              </div>
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter mb-4">{module.title}</h3>
              <p className="text-slate-500 font-medium text-xs leading-relaxed mb-8 flex-grow">{module.desc}</p>
              <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-indigo-600 transition-colors">Accéder au module</span>
                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all">
                  <ChevronRight size={16} />
                </div>
              </div>
              {/* Decorative element */}
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-slate-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Recent Activity / Alerts */}
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
              <History className="text-indigo-500" /> Activité Récente
            </h3>
            <button className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">Voir tout</button>
          </div>
          <div className="space-y-6">
            {[
              { user: 'Moussa Diop', action: 'Nouveau contrat CDI signé', time: 'Il y a 2h', icon: <FileCheck className="text-emerald-500" /> },
              { user: 'Awa Ndiaye', action: 'Génération de la paie Octobre', time: 'Il y a 5h', icon: <DollarSign className="text-blue-500" /> },
              { user: 'Système', action: 'Alerte: 3 contrats expirent bientôt', time: 'Il y a 1j', icon: <ShieldCheck className="text-amber-500" /> },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white rounded-xl shadow-sm border border-slate-100 flex items-center justify-center">
                    {item.icon}
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-900">{item.user}</p>
                    <p className="text-xs text-slate-500 font-medium">{item.action}</p>
                  </div>
                </div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 p-10 rounded-[3rem] text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-3xl rounded-full"></div>
          <h3 className="text-lg font-black uppercase tracking-tighter mb-8 flex items-center gap-3">
            <TrendingUp className="text-indigo-400" /> Aperçu Performance
          </h3>
          <div className="space-y-8 relative z-10">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Taux de Rétention</span>
                <span className="text-sm font-black text-emerald-400">94%</span>
              </div>
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 w-[94%]"></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Objectifs Atteints</span>
                <span className="text-sm font-black text-indigo-400">82%</span>
              </div>
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[82%]"></div>
              </div>
            </div>
            <div className="pt-6">
              <button className="w-full py-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border border-white/10">
                Générer Rapport Analytique RH
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HRDashboard;
