
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Briefcase, 
  Layers, 
  ShieldCheck, 
  FileText, 
  Clock, 
  TrendingUp, 
  Award, 
  Download, 
  Edit3, 
  MoreVertical,
  CheckCircle2,
  AlertCircle,
  Plus,
  History,
  FolderOpen,
  CreditCard,
  Activity,
  UserCheck,
  X
} from 'lucide-react';
import { MOCK_EMPLOYEES, MOCK_CONTRACTS } from '../../constants';
import { motion, AnimatePresence } from 'framer-motion';
import HRModal from './HRModal';

interface EmployeeProfileProps {
  employeeId: string;
  onNavigate: (tab: string, meta?: any) => void;
}

const EmployeeProfile: React.FC<EmployeeProfileProps> = ({ employeeId, onNavigate }) => {
  const [activeTab, setActiveTab] = useState('general');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isContractModalOpen, setIsContractModalOpen] = useState(false);
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');

  const employee = MOCK_EMPLOYEES.find(e => e.id === employeeId);
  const contract = MOCK_CONTRACTS.find(c => c.employeeId === employeeId);

  if (!employee) return <div>Employé non trouvé</div>;

  const handleUpdateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditModalOpen(false);
    setAlertMessage('Profil mis à jour avec succès');
    setShowSuccessAlert(true);
    setTimeout(() => setShowSuccessAlert(false), 3000);
  };

  const handleAddContract = (e: React.FormEvent) => {
    e.preventDefault();
    setIsContractModalOpen(false);
    setAlertMessage('Nouveau contrat ajouté avec succès');
    setShowSuccessAlert(true);
    setTimeout(() => setShowSuccessAlert(false), 3000);
  };

  const handleAddDoc = (e: React.FormEvent) => {
    e.preventDefault();
    setIsDocModalOpen(false);
    setAlertMessage('Document ajouté au dossier');
    setShowSuccessAlert(true);
    setTimeout(() => setShowSuccessAlert(false), 3000);
  };

  const tabs = [
    { id: 'general', label: 'Général', icon: <UserCheck size={16} /> },
    { id: 'contracts', label: 'Contrats', icon: <FileText size={16} /> },
    { id: 'history', label: 'Historique', icon: <History size={16} /> },
    { id: 'documents', label: 'Documents', icon: <FolderOpen size={16} /> },
    { id: 'payroll', label: 'Paie', icon: <CreditCard size={16} /> },
    { id: 'performance', label: 'Performance', icon: <Activity size={16} /> },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 relative">
      {/* Success Alert */}
      <AnimatePresence>
        {showSuccessAlert && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-8 left-1/2 -translate-x-1/2 z-[200] bg-emerald-500 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-4 font-black uppercase text-[10px] tracking-widest"
          >
            <CheckCircle2 size={20} /> {alertMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-6">
          <button 
            onClick={() => onNavigate('hr_employees')}
            className="w-12 h-12 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-slate-100 rounded-[2.5rem] overflow-hidden border-4 border-white shadow-xl">
              <img 
                src={employee.photoUrl || `https://picsum.photos/seed/${employee.id}/200/200`} 
                alt={employee.firstName} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">{employee.firstName} {employee.lastName}</h1>
                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${employee.status === 'ACTIVE' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                  {employee.status}
                </span>
              </div>
              <p className="text-indigo-600 font-black uppercase text-xs tracking-widest">{employee.position} • {employee.department}</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-6 py-3 bg-white border border-slate-100 text-slate-900 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <Download size={16} /> Dossier Complet
          </button>
          <button 
            onClick={() => setIsEditModalOpen(true)}
            className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95"
          >
            <Edit3 size={16} /> Modifier Fiche
          </button>
        </div>
      </div>

      {/* Edit Modal */}
      <HRModal 
        isOpen={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)} 
        title="Modifier la Fiche Employé"
        size="lg"
        footer={
          <div className="flex justify-end gap-4">
            <button 
              onClick={() => setIsEditModalOpen(false)}
              className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all"
            >
              Annuler
            </button>
            <button 
              onClick={handleUpdateEmployee}
              className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl"
            >
              Mettre à jour
            </button>
          </div>
        }
      >
        <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Prénom</label>
            <input type="text" defaultValue={employee.firstName} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nom</label>
            <input type="text" defaultValue={employee.lastName} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Email Professionnel</label>
            <input type="email" defaultValue={employee.email} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Téléphone</label>
            <input type="text" defaultValue={employee.phone} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Département</label>
            <input type="text" defaultValue={employee.department} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Poste</label>
            <input type="text" defaultValue={employee.position} className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
          </div>
        </form>
      </HRModal>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-[2rem] w-fit overflow-x-auto no-scrollbar">
        {tabs.map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-6 py-3 rounded-full font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === tab.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div 
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'general' && (
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-8 flex items-center gap-3">
                    <UserCheck className="text-indigo-500" /> Informations Personnelles
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-10">
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Email Professionnel</p>
                      <p className="text-sm font-bold text-slate-900">{employee.email}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Téléphone</p>
                      <p className="text-sm font-bold text-slate-900">{employee.phone}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Département</p>
                      <p className="text-sm font-bold text-slate-900">{employee.department}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Poste Actuel</p>
                      <p className="text-sm font-bold text-slate-900">{employee.position}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Date d'Embauche</p>
                      <p className="text-sm font-bold text-slate-900">{new Date(employee.hireDate).toLocaleDateString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Manager Direct</p>
                      <p className="text-sm font-bold text-indigo-600">Awa Ndiaye</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-8 flex items-center gap-3">
                    <TrendingUp className="text-emerald-500" /> KPI & Performance Visuelle
                  </h3>
                  <div className="grid sm:grid-cols-3 gap-8">
                    <div className="text-center p-6 bg-slate-50 rounded-[2rem]">
                      <p className="text-3xl font-black text-slate-900 mb-1">92%</p>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Productivité</p>
                    </div>
                    <div className="text-center p-6 bg-slate-50 rounded-[2rem]">
                      <p className="text-3xl font-black text-slate-900 mb-1">4.8/5</p>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Feedback Team</p>
                    </div>
                    <div className="text-center p-6 bg-slate-50 rounded-[2rem]">
                      <p className="text-3xl font-black text-slate-900 mb-1">0</p>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Absences Non Just.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-8">
                <div className="bg-slate-900 p-10 rounded-[3rem] text-white relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 blur-2xl rounded-full"></div>
                  <h3 className="text-sm font-black uppercase tracking-widest mb-8 flex items-center gap-3">
                    <Clock className="text-indigo-400" /> Temps & Présence
                  </h3>
                  <div className="space-y-6 relative z-10">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-400">Congés Restants</span>
                      <span className="text-lg font-black text-white">18.5 Jours</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-400">Heures Sup. (Mois)</span>
                      <span className="text-lg font-black text-emerald-400">+4.5h</span>
                    </div>
                    <div className="pt-4">
                      <button className="w-full py-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all border border-white/10">
                        Consulter Planning
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-8 flex items-center gap-3">
                    <AlertCircle className="text-amber-500" /> Alertes & Rappels
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4 p-4 bg-amber-50 rounded-2xl border border-amber-100">
                      <AlertCircle className="text-amber-500 shrink-0" size={18} />
                      <p className="text-xs font-medium text-amber-800">Le contrat CDI arrive au terme de sa période d'essai dans 15 jours.</p>
                    </div>
                    <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                      <Calendar className="text-blue-500 shrink-0" size={18} />
                      <p className="text-xs font-medium text-blue-800">Entretien annuel d'évaluation prévu le 15 Décembre.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'contracts' && (
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-10">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                  <FileText className="text-indigo-500" /> Historique des Contrats
                </h3>
                <button 
                  onClick={() => setIsContractModalOpen(true)}
                  className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95"
                >
                  <Plus size={16} /> Nouveau Contrat
                </button>
              </div>
              
              {/* Contract Modal */}
              <HRModal 
                isOpen={isContractModalOpen} 
                onClose={() => setIsContractModalOpen(false)} 
                title="Nouveau Contrat"
                size="md"
                footer={
                  <div className="flex justify-end gap-4">
                    <button onClick={() => setIsContractModalOpen(false)} className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all">Annuler</button>
                    <button onClick={handleAddContract} className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl">Enregistrer</button>
                  </div>
                }
              >
                <form className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Type de Contrat</label>
                      <select className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm">
                        <option>CDI</option>
                        <option>CDD</option>
                        <option>Stage</option>
                        <option>Prestation</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Salaire de Base</label>
                      <input type="number" placeholder="Ex: 1500000" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Date de Début</label>
                      <input type="date" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Date de Fin (Optionnel)</label>
                      <input type="date" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                    </div>
                  </div>
                </form>
              </HRModal>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-50">
                      <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</th>
                      <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Début</th>
                      <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Fin</th>
                      <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Salaire de Base</th>
                      <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Statut</th>
                      <th className="text-right py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contract && (
                      <tr className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        <td className="py-6">
                          <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">{contract.type}</span>
                        </td>
                        <td className="py-6 text-sm font-bold text-slate-900">{new Date(contract.startDate).toLocaleDateString()}</td>
                        <td className="py-6 text-sm font-bold text-slate-500">{contract.endDate ? new Date(contract.endDate).toLocaleDateString() : 'Indéterminé'}</td>
                        <td className="py-6 text-sm font-black text-slate-900">{contract.baseSalary.toLocaleString()} {contract.currency}</td>
                        <td className="py-6">
                          <span className="flex items-center gap-2 text-[10px] font-black text-emerald-500 uppercase tracking-widest">
                            <CheckCircle2 size={14} /> Actif
                          </span>
                        </td>
                        <td className="py-6 text-right">
                          <button className="w-10 h-10 bg-white border border-slate-100 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm">
                            <Download size={16} />
                          </button>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
              <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-10 flex items-center gap-3">
                <History className="text-indigo-500" /> Timeline Carrière
              </h3>
              <div className="relative space-y-12 before:absolute before:left-8 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-100">
                {[
                  { date: '15 Janvier 2024', title: 'Promotion: Senior Developer', desc: 'Passage au grade Senior suite aux excellents résultats du projet Kernel.', icon: <Award className="text-amber-500" /> },
                  { date: '01 Juin 2023', title: 'Ajustement Salarial', desc: 'Augmentation annuelle de 8% basée sur la performance.', icon: <TrendingUp className="text-emerald-500" /> },
                  { date: '15 Janvier 2022', title: 'Embauche initiale', desc: 'Recrutement en tant que Fullstack Developer (CDI).', icon: <Briefcase className="text-indigo-500" /> },
                ].map((item, i) => (
                  <div key={i} className="relative pl-20">
                    <div className="absolute left-0 w-16 h-16 bg-white border-4 border-slate-50 rounded-2xl flex items-center justify-center shadow-sm z-10">
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{item.date}</p>
                      <h4 className="text-lg font-black text-slate-900 uppercase tracking-tight mb-2">{item.title}</h4>
                      <p className="text-sm text-slate-500 font-medium leading-relaxed max-w-2xl">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-10">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                  <FolderOpen className="text-indigo-500" /> Dossier Numérique
                </h3>
                <button 
                  onClick={() => setIsDocModalOpen(true)}
                  className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-600 transition-all shadow-xl active:scale-95"
                >
                  <Plus size={16} /> Ajouter Document
                </button>
              </div>

              {/* Document Modal */}
              <HRModal 
                isOpen={isDocModalOpen} 
                onClose={() => setIsDocModalOpen(false)} 
                title="Ajouter un Document"
                size="md"
                footer={
                  <div className="flex justify-end gap-4">
                    <button onClick={() => setIsDocModalOpen(false)} className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all">Annuler</button>
                    <button onClick={handleAddDoc} className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl">Uploader</button>
                  </div>
                }
              >
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Nom du Document</label>
                    <input type="text" placeholder="Ex: CNI_Recto.pdf" className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Catégorie</label>
                    <select className="w-full px-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-bold text-sm">
                      <option>Identité</option>
                      <option>Contrat</option>
                      <option>Diplôme</option>
                      <option>Finance</option>
                      <option>Autre</option>
                    </select>
                  </div>
                  <div className="p-10 border-2 border-dashed border-slate-200 rounded-[2rem] flex flex-col items-center justify-center text-center hover:border-indigo-500 transition-all cursor-pointer group">
                    <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 mb-4 group-hover:scale-110 transition-transform">
                      <Plus size={32} />
                    </div>
                    <p className="text-xs font-bold text-slate-500">Cliquez ou glissez un fichier ici</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">PDF, JPG, PNG (Max 10MB)</p>
                  </div>
                </div>
              </HRModal>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { name: 'Contrat de Travail.pdf', type: 'Contrat', size: '2.4 MB', date: '15/01/2022' },
                  { name: 'CNI_Moussa_Diop.jpg', type: 'Identité', size: '1.1 MB', date: '10/01/2022' },
                  { name: 'Diplome_Master_IT.pdf', type: 'Diplôme', size: '3.8 MB', date: '10/01/2022' },
                  { name: 'RIB_Bancaire.pdf', type: 'Finance', size: '0.5 MB', date: '12/01/2022' },
                ].map((doc, i) => (
                  <div key={i} className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100 hover:border-indigo-200 transition-all group">
                    <div className="flex items-start justify-between mb-6">
                      <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-500 shadow-sm group-hover:scale-110 transition-transform">
                        <FileText size={24} />
                      </div>
                      <button className="text-slate-400 hover:text-slate-900">
                        <MoreVertical size={18} />
                      </button>
                    </div>
                    <h4 className="text-sm font-black text-slate-900 truncate mb-1">{doc.name}</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{doc.type} • {doc.size}</span>
                      <button className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-900 hover:text-white transition-all shadow-sm">
                        <Download size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'payroll' && (
            <div className="space-y-8">
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                  <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                    <CreditCard className="text-indigo-500" /> Historique des Bulletins
                  </h3>
                  <div className="flex items-center gap-3">
                    <select className="bg-slate-50 border-none rounded-xl font-black text-[10px] uppercase tracking-widest text-slate-600 px-4 py-2 focus:ring-2 focus:ring-indigo-500">
                      <option>Année 2024</option>
                      <option>Année 2023</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-4">
                  {[
                    { month: 'Octobre 2024', gross: '1,650,000', net: '1,320,000', status: 'PAID' },
                    { month: 'Septembre 2024', gross: '1,500,000', net: '1,200,000', status: 'PAID' },
                    { month: 'Août 2024', gross: '1,500,000', net: '1,200,000', status: 'PAID' },
                  ].map((slip, i) => (
                    <div key={i} className="flex items-center justify-between p-6 bg-slate-50 rounded-[2rem] hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-slate-100">
                      <div className="flex items-center gap-6">
                        <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-500 shadow-sm">
                          <FileText size={20} />
                        </div>
                        <div>
                          <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{slip.month}</p>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Net à payer: {slip.net} F CFA</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full">Payé</span>
                        <button className="px-6 py-3 bg-white border border-slate-100 text-slate-900 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-900 hover:text-white transition-all shadow-sm">
                          Télécharger PDF
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-8 flex items-center gap-3">
                  <TrendingUp className="text-indigo-500" /> Primes & Avances
                </h3>
                <div className="grid sm:grid-cols-2 gap-8">
                  <div className="p-8 bg-slate-50 rounded-[2.5rem]">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Primes Exceptionnelles (YTD)</p>
                    <p className="text-3xl font-black text-slate-900 mb-6">450,000 F CFA</p>
                    <button className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">Voir le détail</button>
                  </div>
                  <div className="p-8 bg-slate-50 rounded-[2.5rem]">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Avances en cours</p>
                    <p className="text-3xl font-black text-slate-900 mb-6">0 F CFA</p>
                    <button className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">Demander une avance</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'performance' && (
            <div className="space-y-8">
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-10 flex items-center gap-3">
                  <Activity className="text-indigo-500" /> Évaluation de la Performance
                </h3>
                <div className="grid lg:grid-cols-2 gap-12">
                  <div className="space-y-8">
                    <h4 className="text-sm font-black uppercase tracking-widest text-slate-400">Objectifs 2024</h4>
                    {[
                      { label: 'Développement Module Kernel', progress: 95, status: 'En cours' },
                      { label: 'Optimisation Base de Données', progress: 100, status: 'Terminé' },
                      { label: 'Mentorat Junior Developers', progress: 70, status: 'En cours' },
                    ].map((obj, i) => (
                      <div key={i} className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-bold text-slate-900">{obj.label}</span>
                          <span className={`text-[10px] font-black uppercase tracking-widest ${obj.status === 'Terminé' ? 'text-emerald-500' : 'text-indigo-500'}`}>{obj.status}</span>
                        </div>
                        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div className={`h-full transition-all duration-1000 ${obj.status === 'Terminé' ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: `${obj.progress}%` }}></div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="bg-slate-50 p-10 rounded-[3rem] flex flex-col items-center justify-center text-center">
                    <div className="w-32 h-32 bg-white rounded-[2.5rem] shadow-xl flex items-center justify-center mb-6 border border-slate-100">
                      <TrendingUp size={48} className="text-indigo-500" />
                    </div>
                    <p className="text-4xl font-black text-slate-900 tracking-tighter mb-2">A+</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Score Global Performance</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed max-w-xs">
                      Moussa dépasse systématiquement les attentes techniques et fait preuve d'un leadership exemplaire.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tighter mb-8 flex items-center gap-3">
                  <MessageSquare size={20} className="text-indigo-500" /> Feedback Continu
                </h3>
                <div className="space-y-6">
                  {[
                    { from: 'Awa Ndiaye', text: 'Excellente gestion de la crise sur le serveur de prod hier.', date: 'Hier' },
                    { from: 'Jean Koffi', text: 'Merci pour ton aide sur l\'intégration de l\'API Sales.', date: 'Il y a 3 jours' },
                  ].map((f, i) => (
                    <div key={i} className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-black text-slate-900 uppercase tracking-tight">{f.from}</span>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{f.date}</span>
                      </div>
                      <p className="text-sm text-slate-500 font-medium italic">"{f.text}"</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

const MessageSquare = ({ size, className }: { size: number, className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
  </svg>
);

export default EmployeeProfile;
