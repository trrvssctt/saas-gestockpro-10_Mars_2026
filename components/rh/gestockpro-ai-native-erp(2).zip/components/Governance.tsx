
import React, { useState, useEffect } from 'react';
import { 
  Shield, Users, Key, Plus, X, Search, 
  ShieldCheck, UserPlus, Check, ArrowRight,
  RefreshCw, Trash2, Edit3, AlertCircle, Lock
} from 'lucide-react';
import { User, UserRole, SubscriptionPlan } from '../types';
import { authBridge, BASIC_LIMITS } from '../services/authBridge';
import { apiClient } from '../services/api';

const AVAILABLE_ROLES = [
  { id: 'ADMIN', label: 'Administrateur' },
  { id: 'STOCK_MANAGER', label: 'Gestionnaire Stock' },
  { id: 'ACCOUNTANT', label: 'Comptable' },
  { id: 'SALES', label: 'Commercial' },
  { id: 'EMPLOYEE', label: 'Employé' },
];

interface GovernanceProps {
  tenantId: string;
  plan?: SubscriptionPlan;
}

const Governance: React.FC<GovernanceProps> = ({ tenantId, plan }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUserModal, setShowUserModal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  
  const [userData, setUserData] = useState({ name: '', email: '', password: '', roles: [] as string[] });

  const currentUser = authBridge.getSession()?.user;
  const isBasic = currentUser?.planId === 'BASIC';
  const isLimitReached = (isBasic && users.length >= BASIC_LIMITS.MAX_USERS) || (currentUser?.planId === 'FREE_TRIAL' && users.length >= 1);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await apiClient.get('/auth/users');
      setUsers(data || []);
    } catch { setError("Erreur sync Kernel"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLimitReached) {
      setError(`Limite du plan atteinte : maximum ${isBasic ? '3' : '1'} utilisateurs.`);
      return;
    }
    if (userData.roles.length === 0) {
      setError("Sélectionnez au moins un rôle.");
      return;
    }
    setActionLoading(true);
    try {
      await apiClient.post('/auth/users', userData);
      await fetchUsers();
      setShowUserModal(false);
      setUserData({ name: '', email: '', password: '', roles: [] });
      setError(null);
    } catch (err: any) { setError(err.message); }
    finally { setActionLoading(false); }
  };

  return (
    <div className="space-y-12 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase flex items-center gap-3">
            <Shield className="text-indigo-600" size={32} /> Gouvernance & IAM
          </h2>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] mt-1">
            {isBasic ? `Plan Basic : ${users.length} / ${BASIC_LIMITS.MAX_USERS} opérateurs` : 'Gestion Multi-Rôles'}
          </p>
        </div>
        {isLimitReached ? (
           <div className="flex items-center gap-3 px-6 py-4 bg-rose-50 text-rose-600 rounded-2xl border border-rose-100 text-[10px] font-black uppercase tracking-widest shadow-sm">
             <Lock size={16} /> Limite Quota Atteinte
           </div>
        ) : (
          <button onClick={() => { setShowUserModal(true); setError(null); }} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black hover:bg-indigo-600 transition-all shadow-xl flex items-center gap-3 text-xs uppercase tracking-widest">
            <UserPlus size={18} /> NOUVEL OPÉRATEUR
          </button>
        )}
      </div>

      <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/30 text-[9px] font-black text-slate-400 uppercase tracking-widest border-b">
              <th className="px-10 py-6">Opérateur</th>
              <th className="px-10 py-6">Rôles</th>
              <th className="px-10 py-6 text-right">État</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {users.map(u => (
              <tr key={u.id}>
                <td className="px-10 py-6 font-bold uppercase">{u.name}</td>
                <td className="px-10 py-6">
                   <div className="flex flex-wrap gap-2">
                     {(u as any).roles?.map((r: string) => (
                       <span key={r} className="px-2 py-0.5 bg-indigo-50 text-indigo-600 border border-indigo-100 rounded text-[7px] font-black uppercase">{r}</span>
                     ))}
                   </div>
                </td>
                <td className="px-10 py-6 text-right">
                   <div className={`w-2 h-2 rounded-full ml-auto ${u.isActive ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showUserModal && (
        <div className="fixed inset-0 z-[700] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md">
          <div className="bg-white w-full max-w-xl rounded-[3.5rem] p-10 shadow-2xl animate-in zoom-in-95">
             <h3 className="text-xl font-black uppercase mb-8">Nouveau Profil</h3>
             {error && <div className="p-4 bg-rose-50 text-rose-600 rounded-xl text-[10px] font-black uppercase mb-6"><AlertCircle size={16} className="inline mr-2"/> {error}</div>}
             <form onSubmit={handleSubmit} className="space-y-6">
                <input type="text" required value={userData.name} onChange={e => setUserData({...userData, name: e.target.value})} className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 text-sm font-black" placeholder="Nom Complet" />
                <input type="email" required value={userData.email} onChange={e => setUserData({...userData, email: e.target.value})} className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 text-sm font-black" placeholder="Email Professionnel" />
                <input type="password" required value={userData.password} onChange={e => setUserData({...userData, password: e.target.value})} className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 text-sm font-black" placeholder="Clé d'Accès Initiale" />
                <div className="grid grid-cols-2 gap-2">
                   {AVAILABLE_ROLES.map(r => (
                     <button type="button" key={r.id} onClick={() => setUserData(p => ({ ...p, roles: p.roles.includes(r.id) ? p.roles.filter(x => x !== r.id) : [...p.roles, r.id] }))} className={`p-3 rounded-xl border text-[8px] font-black uppercase transition-all ${userData.roles.includes(r.id) ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-slate-50 text-slate-400 border-slate-100 hover:border-indigo-200'}`}>
                        {r.label}
                     </button>
                   ))}
                </div>
                <button type="submit" disabled={actionLoading} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl">
                  {actionLoading ? <RefreshCw className="animate-spin" /> : "CRÉER L'ACCÈS"}
                </button>
             </form>
             <button onClick={() => setShowUserModal(false)} className="w-full mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Annuler</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Governance;
