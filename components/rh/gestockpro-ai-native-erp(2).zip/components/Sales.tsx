
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, Search, Eye, X, RefreshCw, ShoppingCart, Wallet, 
  Loader2, DollarSign, Trash2, ArrowRight,
  Package, PlusCircle, MinusCircle, FileText, 
  CheckCircle, Printer, Truck, Sparkles, Receipt,
  History, Info, ChevronRight, Ban, Boxes, CreditCard,
  Plus as PlusSmall, Minus as MinusSmall, FileDown,
  RotateCcw, AlertTriangle, Edit3, Save, Lock, Clock, Zap, ShieldAlert,
  User as UserIcon, CheckCircle2, Percent, ClipboardList, Filter, Calendar,
  ChevronDown, AlertCircle
} from 'lucide-react';
import { apiClient } from '../services/api';
// Added AppSettings to the imports
import { User, StockItem, Customer, SubscriptionPlan, AppSettings } from '../types';
import { authBridge, BASIC_LIMITS } from '../services/authBridge';
import DocumentPreview from './DocumentPreview';

// Fix: Updated props type to include tenantSettings (passed from App.tsx)
const Sales = ({ currency, user, plan, tenantSettings }: { currency: string, user: User, plan?: SubscriptionPlan, tenantSettings?: AppSettings }) => {
  const [sales, setSales] = useState<any[]>([]);
  const [stocks, setStocks] = useState<StockItem[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  // 🔒 CALCUL QUOTA MENSUEL (Reset automatique basé sur le mois courant)
  const monthlySalesCount = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    return sales.filter(s => {
      const d = new Date(s.createdAt);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && s.status !== 'ANNULE';
    }).length;
  }, [sales]);

  const isBasic = user.planId === 'BASIC';
  const limit = isBasic ? BASIC_LIMITS.MAX_MONTHLY_SALES : (user.planId === 'FREE_TRIAL' ? 5 : 99999);
  const isLimitReached = monthlySalesCount >= limit;

  const fetchData = async () => {
    setLoading(true);
    try {
      const [salesData, stocksData, customersData] = await Promise.all([
        apiClient.get('/sales'),
        apiClient.get('/stock'),
        apiClient.get('/customers')
      ]);
      setSales(salesData || []);
      setStocks(stocksData || []);
      setCustomers(customersData || []);
    } catch (err) { console.error("Kernel Sync Error"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const [saleForm, setSaleForm] = useState({
    customerId: '', 
    items: [] as { productId: string, quantity: number, price: number, name: string, type: 'PRODUCT' }[]
  });

  const cartTotal = useMemo(() => saleForm.items.reduce((sum, i) => sum + (i.price * i.quantity), 0) * 1.18, [saleForm.items]);

  const handleSubmitSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLimitReached) {
      setError(`Limite mensuelle atteinte : maximum ${limit} ventes par mois pour votre plan.`);
      return;
    }
    if (saleForm.items.length === 0) return;
    
    setActionLoading(true);
    try {
      await apiClient.post('/sales', { customerId: saleForm.customerId || null, items: saleForm.items });
      setShowCreateModal(false);
      fetchData();
      setError(null);
    } catch (err: any) { setError(err.message); }
    finally { setActionLoading(false); }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex justify-between items-center bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase flex items-center gap-3">
            <ShoppingCart className="text-indigo-600" size={32} /> Registre des Ventes
          </h2>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] mt-1">
            {isBasic ? `Quota mensuel utilisé : ${monthlySalesCount} / ${limit} ventes` : 'Gestion des Transactions'}
          </p>
        </div>
        {isLimitReached ? (
           <div className="bg-rose-50 text-rose-600 px-6 py-4 rounded-2xl border border-rose-100 text-[10px] font-black uppercase tracking-widest shadow-sm flex items-center gap-2">
              <Lock size={16} /> Limite de {limit} ventes atteinte
           </div>
        ) : (
          <button onClick={() => { setSaleForm({ customerId: '', items: [] }); setShowCreateModal(true); setError(null); }} className="px-10 py-5 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-3 hover:bg-indigo-600 transition-all">
            <Plus size={18} /> NOUVELLE VENTE
          </button>
        )}
      </div>

      {error && <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-[10px] font-black uppercase flex items-center gap-3 animate-in shake"><AlertCircle size={16}/> {error}</div>}

      <div className="bg-white rounded-[3.5rem] border border-slate-100 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/80 text-slate-400 text-[9px] font-black uppercase tracking-widest border-b">
                <th className="px-8 py-6">Référence</th>
                <th className="px-8 py-6">Client</th>
                <th className="px-8 py-6 text-right">Montant TTC</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {sales.map((sale) => (
                <tr key={sale.id} className="hover:bg-slate-50/50 transition-all">
                  <td className="px-8 py-6 font-black text-indigo-600">#{sale.reference}</td>
                  <td className="px-8 py-6 text-xs uppercase font-bold text-slate-600">{sale.customer?.companyName || 'Passage'}</td>
                  <td className="px-8 py-6 text-right font-black text-slate-900">{parseFloat(sale.totalTtc).toLocaleString()} {currency}</td>
                </tr>
              ))}
            </tbody>
          </table>
      </div>

      {showCreateModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-md">
          <div className="bg-white w-full max-w-xl rounded-[4rem] p-10 animate-in zoom-in-95">
             <h3 className="text-xl font-black uppercase mb-8">Nouveau Panier</h3>
             <div className="space-y-4 max-h-[300px] overflow-y-auto mb-10 pr-2">
                {stocks.map(item => (
                  <button key={item.id} onClick={() => setSaleForm({...saleForm, items: [...saleForm.items, { productId: item.id, quantity: 1, price: Number(item.unitPrice), name: item.name, type: 'PRODUCT' }]})} className="w-full p-4 bg-slate-50 rounded-2xl text-left hover:bg-indigo-50 transition-all flex justify-between items-center group">
                    <span className="text-xs font-black uppercase group-hover:text-indigo-600">{item.name}</span>
                    <span className="text-slate-400 font-bold text-[10px]">{Number(item.unitPrice).toLocaleString()}</span>
                  </button>
                ))}
             </div>
             <div className="flex justify-between items-center border-t pt-8 mb-8">
               <div><p className="text-[10px] font-black text-slate-400 uppercase">Total TTC</p><p className="text-2xl font-black">{cartTotal.toLocaleString()} {currency}</p></div>
               <button onClick={handleSubmitSale} disabled={actionLoading || saleForm.items.length === 0} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">
                  {actionLoading ? <Loader2 className="animate-spin" /> : "VALIDER"}
               </button>
             </div>
             <button onClick={() => setShowCreateModal(false)} className="w-full text-[10px] font-black text-slate-400 uppercase">Annuler</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sales;
