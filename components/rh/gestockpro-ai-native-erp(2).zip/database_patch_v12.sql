-- AJOUT DES ATTRIBUTS DE STATUT ET SUPPRESSION LOGIQUE POUR LES SERVICES
ALTER TABLE services ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'actif';
ALTER TABLE services ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP WITH TIME ZONE;

-- Index pour optimiser les performances de filtrage
CREATE INDEX IF NOT EXISTS idx_services_status_active ON services(status) WHERE status = 'actif';