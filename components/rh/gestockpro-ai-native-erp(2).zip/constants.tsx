import { UserRole, User, StockItem, Invoice, AuditLog, Customer, SubscriptionPlan, Subscription, Tenant, Employee, Contract } from './types';

export const MOCK_TENANTS: Tenant[] = [
  { id: 'T1', name: 'TechCorp Solutions', domain: 'techcorp.gestock.pro', isActive: true, plan: 'ENTERPRISE', mrr: 250000, lastPaymentDate: '2023-10-25', paymentStatus: 'UP_TO_DATE', createdAt: '2023-01-01' },
  { id: 'T2', name: 'Global Logistics', domain: 'globallog.gestock.pro', isActive: true, plan: 'PRO', mrr: 85000, lastPaymentDate: '2023-10-20', paymentStatus: 'UP_TO_DATE', createdAt: '2023-05-15' },
  { id: 'T3', name: 'Impayé SARL', domain: 'impaye.gestock.pro', isActive: true, plan: 'BASIC', mrr: 30000, lastPaymentDate: '2023-09-15', paymentStatus: 'FAILED', createdAt: '2023-09-01' },
  { id: 'T-TRIAL', name: 'Nouveau Client', domain: 'test.gestock.pro', isActive: true, plan: 'FREE_TRIAL', mrr: 0, lastPaymentDate: '', paymentStatus: 'TRIAL', createdAt: new Date().toISOString() },
];

export const MOCK_USERS: User[] = [
  { id: '0', name: 'Super Admin', role: UserRole.SUPER_ADMIN, roles: [UserRole.SUPER_ADMIN], email: 'super@gestock.pro', mfaEnabled: true, lastLogin: '2023-10-27 12:00', activeSession: true, isActive: true, tenantId: 'SYSTEM' },
  { id: '1', name: 'Jean Admin', role: UserRole.ADMIN, roles: [UserRole.ADMIN], email: 'admin@gestock.pro', mfaEnabled: true, lastLogin: '2023-10-27 09:15', activeSession: true, isActive: true, tenantId: 'T1' },
  { id: '2', name: 'Marie Stock', role: UserRole.STOCK_MANAGER, roles: [UserRole.STOCK_MANAGER], email: 'marie@gestock.pro', mfaEnabled: true, lastLogin: '2023-10-27 08:30', activeSession: true, isActive: true, tenantId: 'T1' },
  { id: '4', name: 'Lucie Sales', role: UserRole.SALES, roles: [UserRole.SALES], email: 'lucie@gestock.pro', mfaEnabled: false, lastLogin: '2023-10-27 10:00', activeSession: true, isActive: true, tenantId: 'T1' },
];

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  { 
    id: 'FREE_TRIAL', 
    name: 'Essai Gratuit', 
    level: 0,
    price: 0, 
    features: ['14 jours complets', 'Quota: 1 Client, 5 Produits, 5 Ventes', '3 Catégories / 3 Sous-cat.'],
    maxUsers: 1,
    hasAiChatbot: true,
    hasStockForecast: true
  },
  { 
    id: 'BASIC', 
    name: 'Basic', 
    level: 1,
    price: 30000, 
    features: [
      '20 Ventes mensuelles max.', 
      '3 Utilisateurs max. (Admin incl.)', 
      '5 Clients max.', 
      'Catégories & Sous-catégories',
      'Catalogue Stocks & Services',
      'Ventes & Factures',
      'Trésorerie',
      'Gouvernance IAM',
      'Abonnement',
      'Paramètres'
    ],
    maxUsers: 3,
    hasAiChatbot: false,
    hasStockForecast: false
  },
  { 
    id: 'PRO', 
    name: 'Business Pro', 
    level: 2,
    price: 85000, 
    features: ['Illimité', '5 Utilisateurs'], 
    maxUsers: 5,
    hasAiChatbot: true,
    hasStockForecast: true,
    isPopular: true 
  },
  { 
    id: 'ENTERPRISE', 
    name: 'Enterprise Cloud', 
    level: 3,
    price: 250000, 
    features: ['Multi-Entités', '100 Utilisateurs'],
    maxUsers: 100,
    hasAiChatbot: true,
    hasStockForecast: true
  }
];

export const MOCK_CUSTOMERS: Customer[] = [
  { id: 'C1', companyName: 'Client Alpha', mainContact: 'Alpha', email: 'a@a.com', phone: '00', billingAddress: 'Paris', paymentTerms: 30, healthStatus: 'GOOD' }
];

export const MOCK_STOCKS: StockItem[] = [
  { id: 'S1', sku: 'ITM-001', name: 'Article 1', category: 'General', currentLevel: 10, minThreshold: 2, forecastedLevel: 8, unitPrice: 1000, location: 'A1' }
];

export const MOCK_INVOICES: Invoice[] = [
  { id: 'INV-1', customer: 'Client Alpha', customerId: 'C1', date: '2024-01-01', amount: 1000, status: 'PAID', type: 'F-X', taxAmount: 180, transmissionStatus: 'SENT', items: [] }
];

export const MOCK_LOGS: AuditLog[] = [
  { id: 'L1', timestamp: '2024-01-01', userId: '1', userName: 'Admin', action: 'LOGIN', resource: 'System', status: 'SUCCESS', severity: 'LOW' }
];

export const MOCK_SUBSCRIPTION: Subscription = { planId: 'BASIC', status: 'ACTIVE', nextBillingDate: '2024-02-01', paymentHistory: [], autoRenew: true };

// --- HR MOCK DATA ---

export const MOCK_EMPLOYEES: Employee[] = [
  { id: 'E1', firstName: 'Moussa', lastName: 'Diop', email: 'moussa.diop@techcorp.com', phone: '+221 77 123 45 67', department: 'IT', position: 'Senior Developer', status: 'ACTIVE', hireDate: '2022-01-15', tenantId: 'T1' },
  { id: 'E2', firstName: 'Awa', lastName: 'Ndiaye', email: 'awa.ndiaye@techcorp.com', phone: '+221 77 987 65 43', department: 'HR', position: 'HR Manager', status: 'ACTIVE', hireDate: '2021-06-01', tenantId: 'T1' },
  { id: 'E3', firstName: 'Jean', lastName: 'Koffi', email: 'jean.koffi@techcorp.com', phone: '+225 07 11 22 33 44', department: 'Sales', position: 'Sales Representative', status: 'ACTIVE', hireDate: '2023-03-10', tenantId: 'T1' },
];

export const MOCK_CONTRACTS: Contract[] = [
  { id: 'CT1', employeeId: 'E1', type: 'CDI', startDate: '2022-01-15', baseSalary: 1500000, currency: 'F CFA', status: 'ACTIVE' },
  { id: 'CT2', employeeId: 'E2', type: 'CDI', startDate: '2021-06-01', baseSalary: 1200000, currency: 'F CFA', status: 'ACTIVE' },
  { id: 'CT3', employeeId: 'E3', type: 'CDD', startDate: '2023-03-10', endDate: '2024-03-09', baseSalary: 800000, currency: 'F CFA', status: 'ACTIVE' },
];
